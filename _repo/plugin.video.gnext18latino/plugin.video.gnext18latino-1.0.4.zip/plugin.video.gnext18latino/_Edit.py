import xbmcaddon, base64

Decode = base64.decodestring
MainBase = (Decode('aHR0cHM6Ly90ZXh0dXBsb2FkZXIuY29tL2R6N2VxL3Jhdw=='))
addon = xbmcaddon.Addon('plugin.video.gnext18latino')