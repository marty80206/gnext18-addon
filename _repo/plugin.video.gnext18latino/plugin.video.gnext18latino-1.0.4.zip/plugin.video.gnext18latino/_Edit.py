import xbmcaddon, base64

Decode = base64.decodestring
MainBase = (Decode('aHR0cHM6Ly9kbC5kcm9wYm94LmNvbS9zLzd3Ymlxc2VzNWF3cGNjZS9nbmV4dDE4MDEueG1s'))
addon = xbmcaddon.Addon('plugin.video.gnext18latino')


