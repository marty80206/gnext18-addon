import xbmcaddon, base64

Decode = base64.decodestring
MainBase = (Decode('aHR0cHM6Ly90ZXh0dXBsb2FkZXIuY29tL2R3YXhjL3Jhdw=='))
addon = xbmcaddon.Addon('plugin.video.gnext18latino')