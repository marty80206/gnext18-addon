""" The cryptopy.hash package.
    Part of the CryptoPy framework.
"""   
